# Pumpkin Bot (Fabric, Minecraft 1.21.4)

Client-side mod (works in singleplayer and on servers). Requires Fabric API.
Mod Menu is optional but gives you a settings screen.

## Use
1. Put **shears** and an **axe** in your hotbar.
2. Stand near pumpkins and press **P** (rebindable under Controls > Pumpkin Bot),
   or enable it from the Mod Menu config screen.
3. It carves pumpkins in reach with shears, then breaks the carved pumpkins with the axe.

## Settings (Mod Menu > Pumpkin Bot > Configure)
Enabled, Carve pumpkins, Break carved, Scan radius (1-6), Delay in ticks (1-20).
Saved to `config/pumpkinbot.json`.

## Get the .jar without installing anything
1. Create a new GitHub repo and upload this whole folder (including the hidden `.github` folder).
2. Open the repo's **Actions** tab. The build runs on push (or click "Run workflow").
3. Download the **pumpkinbot-jar** artifact. Use the jar that does NOT end in `-sources`.
4. Put it in your `mods` folder with Fabric Loader 0.16+, Fabric API, and (optionally) Mod Menu for 1.21.4.

Local build: install JDK 21 + Gradle, run `gradle build`, jar is in `build/libs/`.

## Notes
- Sneaking prevents shearing, so stay unsneaked.
- Carved pumpkins you placed on purpose (golem builds) within reach will also be broken.
- Using automation on multiplayer servers may break their rules; check before using it.
- Other versions: edit `gradle.properties`. From 1.21.5 on, `selectedSlot` becomes
  `getSelectedSlot()`/`setSelectedSlot()`, and from 1.21.9 key binding categories changed.
