package com.example.pumpkinbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

/**
 * Client-side: works in singleplayer and on servers.
 * 1) Breaks nearby carved pumpkins with an axe from your hotbar.
 * 2) Otherwise carves nearby pumpkins with shears from your hotbar.
 */
public class PumpkinBotClient implements ClientModInitializer {
    private static final double REACH = 4.5;

    private static KeyBinding toggleKey;
    private static int cooldown = 0;
    private static int previousSlot = -1;
    private static BlockPos mining = null;

    @Override
    public void onInitializeClient() {
        PumpkinConfig.get();

        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.pumpkinbot.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_P, "category.pumpkinbot"));

        ClientTickEvents.END_CLIENT_TICK.register(PumpkinBotClient::tick);
    }

    private static void tick(MinecraftClient client) {
        PumpkinConfig cfg = PumpkinConfig.get();
        ClientPlayerEntity player = client.player;

        while (toggleKey.wasPressed()) {
            cfg.enabled = !cfg.enabled;
            cfg.save();
            if (player != null) {
                player.sendMessage(Text.literal("Pumpkin Bot: " + (cfg.enabled ? "ON" : "OFF")), true);
            }
        }

        ClientPlayerInteractionManager im = client.interactionManager;
        if (player == null || im == null || client.world == null) return;

        if (!cfg.enabled || client.currentScreen != null || player.isSpectator()) {
            stopMining(im);
            return;
        }

        // Keep mining the current carved pumpkin until it's gone.
        if (mining != null) {
            boolean stillThere = client.world.getBlockState(mining).isOf(Blocks.CARVED_PUMPKIN);
            boolean inReach = Vec3d.ofCenter(mining).squaredDistanceTo(player.getEyePos()) <= REACH * REACH;
            int axe = findHotbar(player, true);
            if (stillThere && inReach && axe >= 0) {
                player.getInventory().selectedSlot = axe;
                im.updateBlockBreakingProgress(mining, Direction.UP);
                player.swingHand(Hand.MAIN_HAND);
                return;
            }
            stopMining(im);
        }

        if (cooldown > 0) {
            cooldown--;
            return;
        }
        cooldown = cfg.delay;

        BlockPos origin = player.getBlockPos();
        Vec3d eyes = player.getEyePos();
        BlockPos carved = null, pumpkin = null;
        double bestCarved = Double.MAX_VALUE, bestPumpkin = Double.MAX_VALUE;
        int r = cfg.radius;

        for (BlockPos p : BlockPos.iterate(origin.add(-r, -r, -r), origin.add(r, r, r))) {
            Block block = client.world.getBlockState(p).getBlock();
            boolean isCarved = block == Blocks.CARVED_PUMPKIN;
            boolean isPumpkin = block == Blocks.PUMPKIN;
            if (!isCarved && !isPumpkin) continue;

            double d = Vec3d.ofCenter(p).squaredDistanceTo(eyes);
            if (d > REACH * REACH) continue;

            if (isCarved && d < bestCarved) { bestCarved = d; carved = p.toImmutable(); }
            if (isPumpkin && d < bestPumpkin) { bestPumpkin = d; pumpkin = p.toImmutable(); }
        }

        if (cfg.breakCarved && carved != null) {
            int axe = findHotbar(player, true);
            if (axe >= 0) {
                selectSlot(player, axe);
                mining = carved;
                im.attackBlock(mining, Direction.UP);
                player.swingHand(Hand.MAIN_HAND);
                return;
            }
        }

        if (cfg.shearPumpkins && pumpkin != null) {
            int shears = findHotbar(player, false);
            if (shears >= 0) {
                selectSlot(player, shears);
                BlockHitResult hit = new BlockHitResult(Vec3d.ofCenter(pumpkin), Direction.UP, pumpkin, false);
                im.interactBlock(player, Hand.MAIN_HAND, hit);
                player.swingHand(Hand.MAIN_HAND);
                return;
            }
        }

        // Nothing to do: go back to whatever the player was holding.
        if (previousSlot >= 0) {
            player.getInventory().selectedSlot = previousSlot;
            previousSlot = -1;
        }
    }

    private static void selectSlot(ClientPlayerEntity player, int slot) {
        if (previousSlot < 0) previousSlot = player.getInventory().selectedSlot;
        player.getInventory().selectedSlot = slot;
    }

    private static void stopMining(ClientPlayerInteractionManager im) {
        if (mining != null) {
            im.cancelBlockBreaking();
            mining = null;
        }
    }

    /** Finds an axe (axe=true) or shears (axe=false) in the hotbar. */
    private static int findHotbar(ClientPlayerEntity player, boolean axe) {
        for (int i = 0; i < 9; i++) {
            ItemStack s = player.getInventory().getStack(i);
            if (s.isEmpty()) continue;
            if (axe ? s.isIn(ItemTags.AXES) : s.isOf(Items.SHEARS)) return i;
        }
        return -1;
    }
}
