package com.example.pumpkinbot;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

import java.util.function.IntConsumer;

public class PumpkinConfigScreen extends Screen {
    private final Screen parent;
    private final PumpkinConfig cfg = PumpkinConfig.get();

    public PumpkinConfigScreen(Screen parent) {
        super(Text.literal("Pumpkin Bot"));
        this.parent = parent;
    }

    private static Text onOff(String label, boolean value) {
        return Text.literal(label + ": " + (value ? "ON" : "OFF"));
    }

    @Override
    protected void init() {
        int w = 220;
        int x = width / 2 - w / 2;
        int y = height / 4 - 4;
        int step = 24;

        addDrawableChild(ButtonWidget.builder(onOff("Enabled", cfg.enabled), b -> {
            cfg.enabled = !cfg.enabled;
            b.setMessage(onOff("Enabled", cfg.enabled));
        }).dimensions(x, y, w, 20).build());

        addDrawableChild(ButtonWidget.builder(onOff("Carve pumpkins (shears)", cfg.shearPumpkins), b -> {
            cfg.shearPumpkins = !cfg.shearPumpkins;
            b.setMessage(onOff("Carve pumpkins (shears)", cfg.shearPumpkins));
        }).dimensions(x, y + step, w, 20).build());

        addDrawableChild(ButtonWidget.builder(onOff("Break carved (axe)", cfg.breakCarved), b -> {
            cfg.breakCarved = !cfg.breakCarved;
            b.setMessage(onOff("Break carved (axe)", cfg.breakCarved));
        }).dimensions(x, y + step * 2, w, 20).build());

        addDrawableChild(new IntSlider(x, y + step * 3, w, 20, "Scan radius", 1, 6, cfg.radius,
            v -> cfg.radius = v));

        addDrawableChild(new IntSlider(x, y + step * 4, w, 20, "Delay (ticks)", 1, 20, cfg.delay,
            v -> cfg.delay = v));

        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
            .dimensions(x, height - 32, w, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 20, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer,
            Text.literal("Keep shears and an axe in your hotbar"), width / 2, 34, 0xAAAAAA);
    }

    @Override
    public void close() {
        cfg.save();
        client.setScreen(parent);
    }

    private static class IntSlider extends SliderWidget {
        private final String label;
        private final int min, max;
        private final IntConsumer onChange;

        IntSlider(int x, int y, int w, int h, String label, int min, int max, int current, IntConsumer onChange) {
            super(x, y, w, h, Text.empty(), (current - min) / (double) (max - min));
            this.label = label;
            this.min = min;
            this.max = max;
            this.onChange = onChange;
            updateMessage();
        }

        private int current() {
            return min + (int) Math.round(value * (max - min));
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal(label + ": " + current()));
        }

        @Override
        protected void applyValue() {
            onChange.accept(current());
        }
    }
}
